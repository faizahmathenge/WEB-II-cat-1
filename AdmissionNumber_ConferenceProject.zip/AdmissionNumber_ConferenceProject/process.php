<?php
// Server-side processing: validate input and recompute the fee independently of JavaScript.

const REG_FEE = 1000, DAY_FEE = 500, WORKSHOP_FEE = 750, MEAL_FEE = 300, TSHIRT_FEE = 800;

function clean($v) { return htmlspecialchars(trim($v ?? ''), ENT_QUOTES, 'UTF-8'); }

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: register.html');
    exit;
}

$name      = trim($_POST['fullName'] ?? '');
$admission = trim($_POST['admission'] ?? '');
$email     = trim($_POST['email'] ?? '');
$phone     = trim($_POST['phone'] ?? '');
$year      = (int)($_POST['year'] ?? 0);
$category  = $_POST['category'] ?? '';
$days      = (int)($_POST['days'] ?? 0);
$workshop  = $_POST['workshop'] ?? '';
$meal      = ($_POST['meal'] ?? 'No') === 'Yes';
$tshirt    = ($_POST['tshirt'] ?? '') === 'Yes';
$tsize     = $_POST['tsize'] ?? '';

// Basic server-side validation
$errors = [];
if ($name === '' || $admission === '') $errors[] = 'Name and admission number are required.';
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Invalid email address.';
if (!preg_match('/^\d{10}$/', $phone)) $errors[] = 'Phone number must be exactly 10 digits.';
if ($year < 1 || $year > 4) $errors[] = 'Invalid year of study.';
if (!in_array($category, ['Conference Only', 'Workshop Participant'], true)) $errors[] = 'Invalid participation category.';
if ($days < 1 || $days > 3) $errors[] = 'Conference days must be between 1 and 3.';
$workshops = ['Web Development', 'Artificial Intelligence', 'Cybersecurity'];
if ($category === 'Workshop Participant' && !in_array($workshop, $workshops, true)) $errors[] = 'Invalid workshop.';
if ($tshirt && !in_array($tsize, ['S', 'M', 'L', 'XL'], true)) $errors[] = 'Invalid T-shirt size.';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Registration Confirmation</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<nav><a href="index.html">Home</a><a href="register.html">Register</a></nav>
<div class="container">
<?php if ($errors): ?>
  <h2 class="fail">REGISTRATION FAILED</h2>
  <ul><?php foreach ($errors as $e) echo '<li>' . clean($e) . '</li>'; ?></ul>
  <a class="btn" href="register.html">Go back</a>
<?php else:
    // Independent fee calculation (JS total is ignored)
    $hasWorkshop = ($category === 'Workshop Participant');
    $total = REG_FEE + $days * DAY_FEE
           + ($hasWorkshop ? WORKSHOP_FEE : 0)
           + ($meal ? $days * MEAL_FEE : 0)
           + ($tshirt ? TSHIRT_FEE : 0);
    $jsTotal = (int)($_POST['total'] ?? 0);
?>
  <h2 class="success">REGISTRATION SUCCESSFUL</h2>
  <table class="summary">
    <tr><td>Participant</td><td><?= clean($name) ?></td></tr>
    <tr><td>Admission Number</td><td><?= clean($admission) ?></td></tr>
    <tr><td>Email</td><td><?= clean($email) ?></td></tr>
    <tr><td>Phone</td><td><?= clean($phone) ?></td></tr>
    <tr><td>Year of Study</td><td><?= $year ?></td></tr>
    <tr><td>Category</td><td><?= clean($category) ?></td></tr>
    <tr><td>Conference Days</td><td><?= $days ?></td></tr>
    <tr><td>Workshop</td><td><?= $hasWorkshop ? clean($workshop) : 'None' ?></td></tr>
    <tr><td>Meals</td><td><?= $meal ? 'Yes' : 'No' ?></td></tr>
    <tr><td>T-shirt</td><td><?= $tshirt ? 'Yes (size ' . clean($tsize) . ')' : 'No' ?></td></tr>
    <tr><td>TOTAL AMOUNT PAYABLE</td><td><strong>KSh <?= number_format($total) ?></strong></td></tr>
  </table>
  <?php if ($jsTotal !== $total): ?>
    <p class="fail">Note: the amount was recalculated by the server.</p>
  <?php endif; ?>
  <p>Thank you for registering for the Student Technology and Innovation Conference.</p>
<?php endif; ?>
</div>
</body>
</html>
