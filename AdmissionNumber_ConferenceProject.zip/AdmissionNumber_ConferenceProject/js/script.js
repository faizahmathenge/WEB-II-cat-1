// Fee constants (KSh)
const REG_FEE = 1000, DAY_FEE = 500, WORKSHOP_FEE = 750, MEAL_FEE = 300, TSHIRT_FEE = 800;

function $(id) { return document.getElementById(id); }

// Show/hide workshop options and package message based on category
function updateForm() {
  const cat = $("category").value;
  $("workshopBox").classList.toggle("hidden", cat !== "Workshop Participant");
  $("packageMsg").textContent = cat
    ? "Selected package: " + cat
    : "Select a category to see your package.";
  calculateFee();
}

// Show T-shirt size only when the T-shirt box is ticked
function toggleTshirt() {
  $("sizeBox").classList.toggle("hidden", !$("tshirt").checked);
  calculateFee();
}

// Compute total and show it on the page
function calculateFee() {
  let days = parseInt($("days").value, 10);
  if (isNaN(days) || days < 1 || days > 3) days = 0;   // invalid days contribute nothing

  let total = REG_FEE + days * DAY_FEE;
  if ($("category").value === "Workshop Participant") total += WORKSHOP_FEE;
  if ($("meal").value === "Yes") total += days * MEAL_FEE;
  if ($("tshirt").checked) total += TSHIRT_FEE;

  $("totalFee").textContent = "KSh " + total.toLocaleString("en-KE");
  $("totalField").value = total;
  return total;
}

function setError(id, msg) {
  $("err-" + id).textContent = msg;
  $(id).classList.toggle("invalid", msg !== "");
  return msg === "";
}

// Validate all fields before submission
function validateForm() {
  let ok = true;
  ok = setError("fullName", $("fullName").value.trim() === "" ? "Full name is required." : "") && ok;
  ok = setError("admission", $("admission").value.trim() === "" ? "Admission number is required." : "") && ok;

  const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  ok = setError("email", emailRe.test($("email").value.trim()) ? "" : "Enter a valid email address.") && ok;

  ok = setError("phone", /^\d{10}$/.test($("phone").value) ? "" : "Phone number must be exactly 10 digits.") && ok;

  const days = Number($("days").value);
  ok = setError("days", Number.isInteger(days) && days >= 1 && days <= 3 ? "" : "Days must be between 1 and 3.") && ok;

  ok = setError("category", $("category").value === "" ? "Please select a participation category." : "") && ok;

  calculateFee();
  return ok;   // false blocks submission
}

calculateFee();
